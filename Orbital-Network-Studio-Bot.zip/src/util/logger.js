export const log = (...a) => console.log("[Orbital]", ...a);
export const err = (...a) => console.error("[Orbital:ERR]", ...a);
